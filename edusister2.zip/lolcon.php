<?php
include_once 'koneksi.php';
if(isset($_POST['btn-upload']))
{    
     
	$file = rand(1000,100000)."-".$_FILES['file']['name'];
    $file_loc = $_FILES['file']['tmp_name'];
	$file_size = $_FILES['file']['size'];
	$file_type = $_FILES['file']['type'];
	$folder="uploads/";
	$tanggal = date("Ymd");
	
	// new file size in KB
	$new_size = $file_size/81920;  
	// new file size in KB
	
	// make file name in lower case
	$new_file_name = strtolower($file);
	// make file name in lower case
	
	$final_file=str_replace(' ','-',$new_file_name);
	
	if(move_uploaded_file($file_loc,$folder.$final_file))
	{
		$sql="INSERT INTO video_upload(file, tanggal, isi, judul, kategori, nama, id_member, tumb) VALUES('$final_file' ,'$tanggal', '$_POST[isi]', '$_POST[judul]', '$_POST[kategori]', '$_POST[user]', '$_POST[id_member]','MY_VIDEO_POSTER.jpg')";
		mysql_query($sql);
		?>
		<script>
		alert('Sukses Mengunggah Video');
        window.location.href='profil.php?success';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('-_- Upload gagal Coeng');
        window.location.href='upload2.php?fail';
        </script>
		<?php
	}
}
?>