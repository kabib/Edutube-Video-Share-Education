<?php
include('session.php');
?>
<?php
include('ataslogin.php');
?>
<style type="text/css">
<!--
.style3 {font-size: 36px}
.style4 {font-size: 18px}
.style6 {font-size: 15px}
-->
</style>

<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
 <table width="100%" border="0">
  <tr>
    <th colspan="9" scope="col"><div align="center"><span class="style3">STUDIO SAYA</span></div></th>
    </tr>
  <tr>
    <td width="1%">&nbsp;</td>
    <td width="15%">&nbsp;</td>
    <td width="12%">&nbsp;</td>
    <td width="12%">&nbsp;</td>
    <td width="12%">&nbsp;</td>
    <td width="12%">&nbsp;</td>
    <td width="12%">&nbsp;</td>
    <td width="23%">&nbsp;</td>
    <td width="1%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="7" rowspan="8"><table width="100%" border="1" align="center">
      <tr>
        <th width="20%" height="27" scope="col"><div align="center" class="style4">Judul</div></th>
        <th width="23%" scope="col"><div align="center" class="style4">Video</div></th>
        <th width="32%" scope="col"><div align="center" class="style4">Diskripsi</div></th>
        <th width="14%" scope="col"><div align="center" class="style4">Tanggal Upload</div></th>
        <th width="11%" scope="col"><div align="center" class="style4">Aksi</div></th>
      </tr>
       <?php 

		$tampil = mysql_query("select * from video_upload WHERE id_member = '$login_member' ");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
            
      <tr>
        <td><div align="center"><span class="style6">
          <?=$data['judul']?>
        </span></div></td>
        <td>
        <video id="my-video" class="video-js style6" controls preload="auto" width="180" height="100"
  poster="images/<?=$data['tumb']?>" data-setup="{}">
          <div align="center">
            <source src="uploads/<?=$data['file']?>" type='video/mp4'>
            <source src="MY_VIDEO.webm" type='video/webm'>
                  </div>
        </video>        </td>
        <td><div align="center"><span class="style6">
          <?=$data['isi']?>
        </span></div></td>
        <td><div align="center"><span class="style6">
          <?=$data['tanggal']?>
        </span></div></td>
        <td><div align="center"><span class="style6"><a href="edit_video.php?id=<?php echo $data['id_video']; ?>">Edit</a> | <a href="hapus_video.php?id=<?php echo $data['id_video']; ?>">Hapus</a></span></div></td>
      </tr>
      
<?php
}
?>
    </table> </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</div>