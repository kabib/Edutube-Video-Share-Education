<style>
                                 .lol {
                                 border-radius  : 150px;
                                 width : 70px;
                                 }
                                 </style>
<?php

include('ataslogin.php');
include('koneksi.php');
$ambil_data = mysql_query("select * from video_upload where id_video='$_GET[id]'",$koneksi);
$hasil_data = mysql_fetch_array($ambil_data);
?>
<?php
include('koneksi.php');
			$tampiljumlah = mysql_query("select * from video_upload where id_video='$_GET[id]'");
			$data = mysql_fetch_array($tampiljumlah);
			$jumlah = $data['dilihat'];
			$jumlah = $jumlah + 1;
			//update jumlah dibaca setiap detail berita ditampilkan
			$query = mysql_query("update video_upload set dilihat='$jumlah' where id_video='$_GET[id]'");
			$tampil = mysql_query("select * from video_upload where id_video = '$_GET[id]'");
			while ($data=mysql_fetch_array($tampil)):
		?>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
			<div class="show-top-grids">
				<div class="col-sm-8 single-left">
					<div class="song">
						<div class="song-info">
							<h3><?=$hasil_data['judul']?></h3>	
					</div>
						<div class="video-grid">
							<video id="my-video" class="video-js" autoplay = "true" controls preload="auto" width="555" height="360"
  poster="MY_VIDEO_POSTER.jpg" data-setup="{  }">
    <source src="uploads/<?=$hasil_data['file']?>" type='video/mp4'>
    <source src="MY_VIDEO.webm" type='video/webm'>
  </video>
						</div>
					</div>
					<div class="song-grid-right">
						<div class="share">
							<h5>Bagikan</h5>
							<ul>
								<li><a href="https://www.facebook.com/sharer/sharer.php?sdk=joey&u=http%3A%2F%2Fedutube.ga%2Fvideolengkap.php?id=<?=$hasil_data['id_video']?>&display=popup&ref=plugin&src=share_button" target="_blank" class="icon fb-icon">Facebook</a></li>
	
								<li><a href="http://twitter.com/intent/tweet?url=http://www.edutube.ga/videolengkap.php?id=<?=$hasil_data['id_video']?>&amp;text=ayo+belajar++share+di+Edutube+@indonesiabisa&amp;hashtags=EdutubeONE" target="_blank"" class="icon twitter-icon">Twitter</a></li>
		
								<li class="view"><?=$hasil_data['dilihat']?> tayang</li>
							</ul>
						</div>
					</div>
					<div class="clearfix"> </div>
					<div class="published">
						<script src="jquery.min.js"></script>
							<script>
								$(document).ready(function () {
									size_li = $("#myList li").size();
									x=1;
									$('#myList li:lt('+x+')').show();
									$('#loadMore').click(function () {
										x= (x+1 <= size_li) ? x+1 : size_li;
										$('#myList li:lt('+x+')').show();
									});
									$('#showLess').click(function () {
										x=(x-1<0) ? 1 : x-1;
										$('#myList li').not(':lt('+x+')').hide();
									});
								});
							</script>
							<div class="load_more">	
								<ul id="myList">
									<li>
										<h4>Published on <?=$hasil_data['tanggal']?></h4>
										<p><?=$hasil_data['isi']?></p>
										<div class="load-grids">
											<div class="load-grid">
												<p>Kategori</p>
											</div>
											<div class="load-grid">
												<a href="#"><?=$hasil_data['kategori']?></a>
											</div>
                                      
                                        <div class="clearfix"> </div>
										</div>
									</li>
								</ul>
							</div>
					</div>
					
				</div>
                <div class="col-md-4 single-right">
					<h3>Video Terbaru</h3>
                     <?php 

		$tampil = mysql_query("select * from video_upload ORDER BY id_video DESC LIMIT 5");
		while($data=mysql_fetch_array($tampil)){
			?>
					<div class="single-grid-right">
						<div class="single-right-grids">
							<div class="col-md-4 single-right-grid-left">
								<a href="videolog.php?id=<?php echo $data['id_video']; ?>"> <video width="120" height="90" controls poster="images/<?=$data['tumb']?>">
  <source src="uploads/<?=$data['file']?>" type="video/mp4">
  <source src="movie.ogg" type="video/ogg">
Your browser does not support the video tag.
</video> </a>
							</div>
							<div class="col-md-8 single-right-grid-right">
								<a href="videolog.php?id=<?php echo $data['id_video']; ?>" class="title"> <?=$data['judul']?></a>
								<p class="author"><a href="#" class="author"><?=$data['nama']?></a></p>
								<p class="views">Kategori : <?=$data['kategori']?></p>
							</div>
							<div class="clearfix"> </div>
						</div>
                        
                        
                       
						
					</div><?PHP
						}
						?>
				</div>
                
                  <div class="all-comments">
						<div class="all-comments-info">
							
							<div class="box">
								<form action="aksikomen.php" method="post">
									<textarea placeholder="Komentar" required=" " name="komentar"></textarea>
                                              <input type="hidden" name="id_video" id="id_video" value="<?=$hasil_data['id_video']?>"> 
                      <input type="hidden" name="nama_user" id="nama_user" value="<?php echo $login_session; ?>">
                      <input type="hidden" name="id_member" id="id_member" value="<?php echo $login_member; ?>"> 
                  <input type="hidden" name="foto" id="foto" value="<?php echo $login_foto; ?>"> 
									<input type="submit" value="Kirim Komentar">
									<div class="clearfix"> </div>
								</form>
							</div>
							
						</div>
            
                           <?php 

		$tampil = mysql_query("select * from komentar where id_video='$_GET[id]'",$koneksi);
		while($data=mysql_fetch_array($tampil)){
		
			?>
					<div class="media-grids">
							
                            
                               <div class="media">
                                 <h5><?=$data['nama_user']?></h5>
                                 <div class="media-left">
                               
                                 
										 <img src="images/<?=$data['foto']?>" class="lol"/> 
								 </div>
                                 <div class="media-body">
                                   <p><?=$data['isi_komentar']?></p>
                                   <span>Komentar Pada : <?=$data['tanggal']?> </div>
                               </div>
                               <?php
							}
							?>
                            
</div>

			  </div>
              
				</div>
                
                
			
			</div>
            
          
			<div class="clearfix"> </div>
            
		</div>
        
		<div class="clearfix"> </div>
        
	<div class="drop-menu">
		<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu4">
		  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Regular link</a></li>
		  <li role="presentation" class="disabled"><a role="menuitem" tabindex="-1" href="#">Disabled link</a></li>
		  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another link</a></li>
		</ul>
	</div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.min.js"></script>
      <script src="jsvid/video.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    
  </body>
</html>
<?php endwhile ?>