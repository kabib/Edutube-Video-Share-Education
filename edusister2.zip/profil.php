<?php
include('session.php');
include('ataslogin.php');
?>
<style type="text/css">
<!--
.style1 {font-size: 24px}
-->
</style>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
  <table width="100%" border="0">
    <tr>
      <th height="89" colspan="10" scope="col"><div align="center"><span class="style1">Selamat Datang <?php echo $login_session; ?></span></div></th>
    </tr>
    <tr>
      <td width="10%">&nbsp;</td>
      <td colspan="2"><div align="center"><a href="edit_profil.php"><img src="images/profle.png" width="128" height="128"></a></div></td>
      <td width="10%"><div align="center"></div></td>
      <td colspan="2"><div align="center"><a href="studio.php"><img src="images/bookshelf.png" width="128" height="128"></a></div></td>
      <td width="10%"><div align="center"></div></td>
      <td colspan="2"><div align="center"><a href="lihat_profil.php"><img src="images/tools.png" width="128" height="128"></a></div></td>
      <td width="10%">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2"><div align="center" class="style1"><a href="edit_profil.php">Edit Profil</a></div></td>
      <td><div align="center"><span class="style1"></span></div></td>
      <td colspan="2"><div align="center" class="style1"><a href="studio.php">Studio Saya</a></div></td>
      <td><div align="center"><span class="style1"></span></div></td>
      <td colspan="2"><div align="center" class="style1"><a href="lihat_profil.php">Lihat Profil</a></div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td width="10%">&nbsp;</td>
      <td width="10%">&nbsp;</td>
      <td>&nbsp;</td>
      <td width="10%">&nbsp;</td>
      <td width="10%">&nbsp;</td>
      <td>&nbsp;</td>
      <td width="10%">&nbsp;</td>
      <td width="10%">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2"><div align="center"><a href="panduan.php"><img src="images/crossroads.png" width="128" height="128"></a></div></td>
      <td><div align="center"></div></td>
      <td colspan="2"><div align="center"><a href="upload2.php"><img src="images/upload.png" width="128" height="128"></a></div></td>
      <td><div align="center"></div></td>
      <td colspan="2"><div align="center"><a href="logout.php"><img src="images/x.png" width="128" height="128"></a></div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2"><div align="center" class="style1"><a href="panduan.php">Panduan</a></div></td>
      <td><div align="center"><span class="style1"></span></div></td>
      <td colspan="2"><div align="center" class="style1"><a href="upload.php">Upload</a></div></td>
      <td><div align="center"><span class="style1"></span></div></td>
      <td colspan="2"><div align="center" class="style1"><a href="logout.php">Keluar</a></div></td>
      <td>&nbsp;</td>
    </tr>
  </table>
</div>
