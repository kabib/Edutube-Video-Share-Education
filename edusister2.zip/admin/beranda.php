
            
            <?php
			include 'head.php';
			?>
            <style type="text/css">
<!--
.style1 {font-size: 16}
-->
            </style>
            
            


        
        <div class="warper container-fluid">
        	
            <div class="page-header"><h1>Beranda <small> Edutube Indonesia</small></h1></div>
                        <center>
            
            <div class="row">
            
        	<div class="col-md-6 col-lg-3">
                	<div class="panel panel-default clearfix dashboard-stats rounded">
                    	<span id="dashboard-stats-sparkline1" class="sparkline transit"></span>
                    	<i class="fa fa-shopping-cart bg-danger transit stats-icon"></i>
                        <h3 class="transit">
 <?php
 $table = "member";
$sql = "SELECT count(*) AS jumlah FROM $table";
$query = mysql_query($sql); 
$result = mysql_fetch_array($query) ;

echo "{$result['jumlah']} <br/>";
?> <small class="text-green"><i class="fa fa-caret-up"></i> 8%</small></h3>
                        <p class="text-muted transit">User Terdaftar</p>
                    </div>
                </div>
                
                  <div class="row">
            
            	<div class="col-md-6 col-lg-3">
                	<div class="panel panel-default clearfix dashboard-stats rounded">
                    	<span id="dashboard-stats-sparkline1" class="sparkline transit"></span>
                    	<i class="fa fa-shopping-cart bg-danger transit stats-icon"></i>
                        <h3 class="transit">
 <?php
 $table = "admin";
$sql = "SELECT count(*) AS jumlah FROM $table";
$query = mysql_query($sql); 
$result = mysql_fetch_array($query) ;

echo "{$result['jumlah']} <br/>";
?> <small class="text-green"><i class="fa fa-caret-up"></i> 8%</small></h3>
                        <p class="text-muted transit">Admin Terdaftar</p>
                    </div>
                </div>
                
              <div class="col-md-6 col-lg-3">
                	<div class="panel panel-default clearfix dashboard-stats rounded">
                    	<span id="dashboard-stats-sparkline2" class="sparkline transit"></span>
                    	<i class="fa fa-tags bg-info transit stats-icon"></i>
                        <h3 class="transit">
 <?php
 $table = "video_upload";
$sql = "SELECT count(*) AS jumlah FROM $table";
$query = mysql_query($sql);
$result = mysql_fetch_array($query);
echo "{$result['jumlah']} <br/>";
?> <small class="text-red"><i class="fa fa-caret-down"></i> 6%</small></h3>
                        <p class="text-muted transit">Video Terupload</p>
                    </div>
                    
                </div>
             <br/><br/>
                <table width="100%" border="0" align="center">
              <tr>
                <th width="5%" height="166" scope="col">&nbsp;</th>
                <th width="22%" scope="col">&nbsp;</th>
                <th width="12%" scope="col"><div align="center">
                  <p><a href="user.php"><img src="../ico/20150831_55e46b1c0c44b.png" width="100" height="100" class="style1" /></a></p>
                  <p><a href="user.php">Daftar User</a></p>
                </div></th>
                <th width="12%" scope="col"><div align="center">
                  <p><a href="daftarvideo.php"><img src="../ico/Play-icon.png" width="100" height="100" /></a></p>
                  <p><a href="daftarvideo.php">Daftar Video </a></p>
                </div></th>
                <th width="12%" scope="col"><div align="center">
                  <p><a href="daftarkomentar].php"><img src="../ico/bookshelf.png" width="100" height="100" /></a></p>
                  <p><a href="daftarkomentar].php">Daftar Komentar</a></p>
                </div></th>
                <th width="12%" scope="col"><div align="center">
                  <p><a href="logout.php"><img src="../ico/popout-flat.png" width="100" height="100" /></a></p>
                  <p><a href="logout.php">Keluar</a></p>
                </div></th>
                <th width="20%" scope="col">&nbsp;</th>
                <th width="5%" scope="col">&nbsp;</th>
              </tr>
            </table>
              </div>
               </div></div>
                
               </center>
            
            <?php
			include 'kaki.php'
			?>