<?php
		 include("../koneksi.php");
$query = "delete from member where id_member = '$_GET[id]'";
$result = mysql_query($query);

if ($result) {
	header("location: beranda.php");
}
else {
	echo "proses hapus gagal !.";
}
?>
