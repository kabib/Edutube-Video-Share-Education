<?php
		 include("../koneksi.php");
$query = "delete from komentar where id_komentar = '$_GET[id]'";
$result = mysql_query($query);

if ($result) {
	header("location: beranda.php");
}
else {
	echo "proses hapus gagal !.";
}
?>
