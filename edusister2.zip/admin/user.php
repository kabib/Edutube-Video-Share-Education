
            
            <?php
			include 'head.php';
			?>
           <div class="warper container-fluid">
        	
            <div class="page-header"><h1>Daftar User <small>Edutube</small></h1></div>
            
            
            
                <div class="panel panel-default">
                    <div class="panel-heading">User Terdaftar</div>
                    <div class="panel-body">
                    
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Nama</th>
                                    <th>Alamat</th>
                                    <th>Email</th>
                                    <th>No HP</th>
                                       <th>Aksi</th>
                                </tr>
                            </thead>
                             <?php 
include'../koneksi.php';
		$tampil = mysql_query("select * from member ORDER BY id_member DESC");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
                            <tbody>
                                <tr class="odd gradeX">
                                    <td><?php echo $data['username']; ?></td>
                                    <td><?php echo $data['nama']; ?></td>
                                    <td><?php echo $data['alamat']; ?></td>
                                    <td class="center"><?php echo $data['email']; ?></td>
                                    <td class="center"><?php echo $data['no_hp']; ?></td>
                                      <td class="center"><a href="hapus_user.php?id=<?php echo $data['id_video']; ?>">Hapus</a></td>
                              </tr>
                                
                            </tbody>
                            <?php
							}
							?>
                        </table>

                    </div>
                </div>
                
                
              
                
                
             
                </div>
            <?php
			include 'kaki.php'
			?>