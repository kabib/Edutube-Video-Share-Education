
            
            <?php
			include 'head.php';
			?>
           <div class="warper container-fluid">
        	
            <div class="page-header"><h1>Daftar Komentar <small>Edutube</small></h1></div>
            
            
            
                <div class="panel panel-default">
                    <div class="panel-heading">Daftar Komentar</div>
                    <div class="panel-body">
                    
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
                            <thead>
                                <tr>
                                    <th>Komentator</th>
                                    <th>Pada Video dengan ID</th>
                                    <th>tanggal</th>
                                    <th>isi Komwntar</th>
                                   
                                       <th>Aksi</th>
                                </tr>
                            </thead>
                             <?php 
include'../koneksi.php';
		$tampil = mysql_query("select * from komentar ORDER BY id_komentar DESC");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
                            <tbody>
                                <tr class="odd gradeX">
                                    <td><?php echo $data['nama_user']; ?></td>
                                    <td><?php echo $data['id_video']; ?></td>
                                    <td><?php echo $data['tanggal']; ?></td>
                                    <td class="center"><?php echo $data['isi_komentar']; ?></td>
                                 
                                      <td class="center"><a href="hapus_video.php?id=<?php echo $data['id_video']; ?>">Hapus</a></td>
                              </tr>
                                
                            </tbody>
                            <?php
							}
							?>
                        </table>

                    </div>
                </div>
                
                
              
                
                
             
                </div>
            <?php
			include 'kaki.php'
			?>