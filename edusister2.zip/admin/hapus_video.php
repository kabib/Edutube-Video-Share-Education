<?php
		 include("../koneksi.php");
$query = "delete from video_upload where id_video = '$_GET[id]'";
$result = mysql_query($query);

if ($result) {
	header("location: user.php");
}
else {
	echo "proses hapus gagal !.";
}
?>
