<?php
include '../koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Admin Edutube</title>

	<meta name="description" content="">
	<meta name="author" content="Akshay Kumar">

	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap/bootstrap.css" /> 

	<!-- Calendar Styling  -->
    <link rel="stylesheet" href="assets/css/plugins/calendar/calendar.css" />
    
    <!-- Fonts  -->
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,500,600,700,300' rel='stylesheet' type='text/css'>
    
    <!-- Base Styling  -->
    <link rel="stylesheet" href="assets/css/app/app.v1.css" />

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body data-ng-app>

	
    <!-- Preloader -->
    <div class="loading-container">
      <div class="loading">
        <div class="l1">
          <div></div>
        </div>
        <div class="l2">
          <div></div>
        </div>
        <div class="l3">
          <div></div>
        </div>
        <div class="l4">
          <div></div>
        </div>
      </div>
    </div>
    <!-- Preloader -->
    	
    
	<aside class="left-panel">
    		
            <div class="user text-center">
                  <img src="assets/images/avtar/user.png" class="img-circle" alt="...">
                  <h4 class="user-name">Admin</h4>
                  
                  <div class="dropdown user-login">
                 <a href="logout.php" <button class="btn btn-xs dropdown-toggle btn-rounded" type="button" data-toggle="dropdown" aria-expanded="true">
                    <i class="fa fa-circle status-icon available"></i> Available <i class="fa fa-angle-down"></i>
                  </button></a>
                  <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
         
                    <li role="presentation"><a role="menuitem" href="logout.php"><i class="fa fa-circle status-icon signout"></i> Keluar</a></li>
                  </ul>
                  </div>	 
            </div>
            
                       <nav class="navigation">
            	<ul class="list-unstyled">
                	<li class="active"><a href="beranda.php"><i class="fa fa-bookmark-o"></i><span class="nav-label">Beranda</span></a></li>
                  <li class="has-submenu"><a href="user.php"><i class="fa fa-comment-o"></i> <span class="nav-label">Daftar User</span></a></li>
                  <li class="has-submenu"><a href="daftarvideo.php"><i class="fa fa-flag-o"></i> <span class="nav-label">Daftar Video</span></a></li>
              <li class="has-submenu"><a href="daftarkomentar].php"><i class="fa fa-file-text-o"></i> <span class="nav-label">Daftar Komentar</span></a>
                    </li>
              
                    <li class="has-submenu"><a href="logout.php"><i class="fa fa-file-text-o"></i> <span class="nav-label">Keluar</span></a>
                    </li>
                </ul>
            </nav>
            
    </aside>
    <!-- Aside Ends-->
    
     
    
    <section class="content">
    	
        <header class="top-head container-fluid">
           
            <ul class="nav-toolbar">
            	
               
                <li class="dropdown"><a href="logout.php" data-toggle="dropdown"><i class="fa fa-ellipsis-v"></i></a>
                	<div class="dropdown-menu lg pull-right arrow panel panel-default arrow-top-right">
                    	<div class="panel-heading">
                        	Keluar Akun
                        </div>
                        <div class="panel-body text-center">
                        	<div class="row">
                            	
                                <div class="col-xs-6 col-sm-4"><a href="logout.php" class="text-purple"><span class="h2"><i class="fa fa-calendar-o"></i></span><p class="text-gray no-margn">Keluar</p></a></div>
                                
                               
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </header>
        <!-- Header Ends -->