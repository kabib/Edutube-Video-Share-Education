

<?php
include("koneksi.php");
$query = "insert into member (username, nama, alamat, no_hp, email, password, foto) values ('$_POST[user]', '$_POST[namalengkap]', '$_POST[alamat]', '$_POST[nohp]', '$_POST[email]', '$_POST[password]', 'profil.png')";
$result = mysql_query($query);

if ($result) {
	header("location: index.php");
}
else {
	echo "proses simpan gagal !.";
}
?>