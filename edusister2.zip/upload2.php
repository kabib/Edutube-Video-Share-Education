<?php
include('session.php');
?>
<?php
include('ataslogin.php');
?>
<style type="text/css">
<!--
.style1 {font-size: 18px}
.style2 {font-size: 24px}
-->
</style>

<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
 <table width="100%" border="0">
  <tr>
    <th width="10%" scope="col">&nbsp;</th>
    <th width="8%" scope="col">&nbsp;</th>
    <th width="13%" scope="col">&nbsp;</th>
    <th colspan="3" class="style2" scope="col">UNGGAH VIDEO</th>
    <th width="13%" scope="col">&nbsp;</th>
    <th width="5%" scope="col">&nbsp;</th>
    <th width="12%" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td width="13%">&nbsp;</td>
    <td width="13%">&nbsp;</td>
    <td width="13%">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="7" rowspan="8">
    
     <form action="lolcon.php" method="post" enctype="multipart/form-data">
	<p><span class="style1">Judul Video : </span><br/>
                <label>
                <input name="judul" type="text" class="form-control" id="judul">
                </label>
          </p>
<p><span class="style1">Kategori : </span><br/>
                <label>
                <select name="kategori" id="kategori" class="form-control">
                  <option value="Kesehatan">Kesehatan</option>
                  <option value="Religi">Religi</option>
                  <option value="Pendidikan">Pendidikan</option>
                  <option value="Motivasi">Motivasi</option>
                </select>
                </label>
              </p>
    <p><span class="style1">Pilih File :</span> <br/>
	  <input type="file" name="file"  />
    </p>
    <span class="style1">Deskripsi Video : </span><br>
<textarea name="isi" cols="40" rows="8" class="form-control" id="isi"></textarea>
<br>  <label>
              <input name="user" type="hidden" id="textfield" value="<?php echo $login_session; ?>" />
              <input name="id_member" type="hidden" id="textfield" value="<?php echo $login_member; ?>" />
              </label>
    <p>               
	<button type="submit" name="btn-upload">Unggah Video</button></p>
	<p>&nbsp;</p>
</form>

    <?php
	if(isset($_GET['success']))
	{
		?>
       
        <?php
	}
	else if(isset($_GET['fail']))
	{
		?>
        <label>Problem While File Uploading !</label>
        <?php
	}
	else
	{
		?>
        <label>Bisa Mengupload File MP4, 3GP, FL</label>
        <?php
	}
	?></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</div>