<?php
 include ('koneksi.php');
$filename=$_FILES['gambar']['name'];
$move=move_uploaded_file($_FILES['gambar']['tmp_name'],'foto/'.$filename);
if(empty($filename))   //jika gambar kosong atau tidak di ganti
{
                $update=mysql_query("update member set nama='$_POST[nama]',alamat='$_POST[alamat]',no_hp='$_POST[no_hp]',tentang='$_POST[tentang]' where id_member='$_POST[id_member]' ") or die ("gagal update ");
echo "<script>alert ('data telah di update ');document.location='lihat_profil.php' </script> ";
}
elseif (!empty($filename)) // jika gambar di ganti
{
                $update=mysql_query("update member set nama='$_POST[nama]',alamat='$_POST[alamat]',no_hp='$_POST[no_hp]',tentang='$_POST[tentang]',foto='$filename' where id_member='$_POST[id_member]' ") or die ("gagal update gambar ");
echo "<script>alert ('data telah di update ');document.location='lihat_profil.php' </script> ";
}
?>
