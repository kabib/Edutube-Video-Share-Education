<?php
 include ('koneksi.php');
$filename=$_FILES['gambar']['name'];
$move=move_uploaded_file($_FILES['gambar']['tmp_name'],'images/'.$filename);
if(empty($filename))   //jika gambar kosong atau tidak di ganti
{
                $update=mysql_query("update video_upload set judul='$_POST[judul]',isi='$_POST[isi]' where id_video='$_POST[id_video]' ") or die ("gagal update ");
echo "<script>alert ('data telah di update ');document.location='studio.php' </script> ";
}
elseif (!empty($filename)) // jika gambar di ganti
{
                $update=mysql_query("update video_upload set judul='$_POST[judul]',isi='$_POST[isi]',tumb='$filename' where id_video='$_POST[id_video]' ") or die ("gagal update gambar ");
echo "<script>alert ('data telah di update ');document.location='studio.php' </script> ";
}
?>
