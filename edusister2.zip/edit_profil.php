<?php
include('session.php');
?>
<?php
include('ataslogin.php');
?>
<style type="text/css">
<!--
.style4 {
	font-size: 36px
}
-->
</style>
<?php
$query = "select * from member where id_member = '$login_member'";
$result = mysql_query($query);
$data = mysql_fetch_array($result);
?>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
 <table width="100%" border="0">
  <tr>
    <th colspan="7" scope="col"><div align="center" class="style4">EDIT AKUN</div></th>
    </tr>
  <tr>
    <td width="10%">&nbsp;</td>
    <td width="8%">&nbsp;</td>
    <td width="13%">&nbsp;</td>
    <td><div align="center">EDUTUBE</div></td>
    <td width="13%">&nbsp;</td>
    <td width="5%">&nbsp;</td>
    <td width="12%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="5" rowspan="8">
       <form action="profil_aksi.php" method="post" enctype="multipart/form-data"><br/><br/>
      <table width="90%" border="0">
        <tr>
          <th width="16%" height="43" scope="col"><div align="left"><strong>Nama</strong></div></th>
          <th width="3%" scope="col"><div align="center"><strong>:</strong></div></th>
          <th width="56%" scope="col"><label>
            <div align="left">
              <input type="text" name="nama" id="nama" value="<?php echo $data['nama']; ?>">
              <input type="hidden" name="id_member" id="id_member" value="<?php echo $data['id_member']; ?>"> 
              </div>
          </label></th>
          <th width="13%" scope="col">&nbsp;</th>
          <th width="6%" scope="col">&nbsp;</th>
        </tr>
        <tr>
          <td><div align="left"><strong>Alamat</strong></div></td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <div align="left">
              <p>
                <textarea name="alamat" id="diskripsi"><?php echo $data['alamat']; ?></textarea>
              </p>
              <p>&nbsp;</p>
            </div>
          </label></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td width="1%">&nbsp;</td>
          <td width="1%">&nbsp;</td>
          <td width="1%">&nbsp;</td>
          <td width="1%">&nbsp;</td>
          <td width="1%">&nbsp;</td>
          <td width="1%">&nbsp;</td>
        </tr>
      
        <tr>
          <td><div align="left"><strong>Tentang</strong></div></td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
              <div align="left">
                <textarea name="tentang" id="diskripsi"><?php echo $data['tentang']; ?></textarea>
              </div>
            </label></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><div align="left"><strong>No HP</strong></div></td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
              <div align="left">
                <input name="no_hp" type="text" id="diskripsi" value="<?php echo $data['no_hp']; ?>">
              </div>
            </label></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><strong>Ganti Foto</strong></td>
          <td>:</td>
          <td>          *kosongkan jika gambar tidak di ubah </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><div align="center"></div></td>
          <td><label>
            Foto Profil
              <p><img src="foto/<?php echo $data['foto']; ?>" width="126" height="116">            
                <br/><input type=file name=gambar>
              </p>
            <div align="center">
              <input type="submit" name="button" id="button" value="Simpan">
              </div>
          </label></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>   
    </form>  </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</div>