<?php
include('session.php');
?>
<?php
include('ataslogin.php');
?>
<style type="text/css">
<!--
.style1 {font-size: 24px}
-->
</style>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
  <table width="100%" border="0">
    <tr>
      <th colspan="10" class="style1" scope="col"><div align="center">Upload Video Saya</div></th>
    </tr>
    <tr>
      <td width="10%">&nbsp;</td>
      <td width="82%" colspan="8" rowspan="8">
      
      <form enctype="multipart/form-data" method="POST" action="simpan_aksi.php">
          <p>Judul Video : <br/>
                <label>
                <input name="judul" type="text" class="form-control" id="judul">
                </label>
          </p>
               <p>Kategori : <br/>
                <label>
                <select name="kategori" id="kategori" class="form-control">
                  <option value="Kesehatan">Kesehatan</option>
                  <option value="Religi">Religi</option>
                  <option value="Pendidikan">Pendidikan</option>
                  <option value="Motivasi">Motivasi</option>
                </select>
                </label>
              </p>
              <p>Pilih File Video : <br/>
                <input name="fupload" type="file" class="form-control-static">
                </p>
                
            
          Deskripsi Video : <br>
<textarea name="isi" cols="40" rows="8" class="form-control" id="isi"></textarea>
<br>  <label>
              <input name="user" type="hidden" id="textfield" value="<?php echo $login_session; ?>" />
              </label>
<input type=submit class="btn-group" value=Kirim Proposal>
          </p>
        </form>      </td>
      <td width="8%">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</div>
