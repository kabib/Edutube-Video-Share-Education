
<?php

include('atasbiasa.php');
include('koneksi.php');
?>
 
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
			<div class="main-grids">
				<div class="top-grids">
					<div class="recommended-info">
						<h3>Video Terbaru</h3>
					
                    </div>
                   
                   <?php 

		$tampil = mysql_query("select * from video_upload ORDER BY id_video DESC LIMIT 3");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
					<div class="col-md-4 resent-grid recommended-grid slider-top-grids">
						<div class="resent-grid-img recommended-grid-img">
				<a href="videolengkap.php?id=<?php echo $data['id_video']; ?>"><video id="my-video" class="video-js" controls preload="auto" width="355" height="260"
  poster="images/<?=$data['tumb']?>" data-setup="{}">
    <source src="uploads/<?=$data['file']?>" type='video/mp4'>
    <source src="MY_VIDEO.webm" type='video/webm'>
  </video></a>	
						</div>
                        

						<div class="resent-grid-info recommended-grid-info">
							<h3><a href="videolengkap.php?id=<?php echo $data['id_video']; ?>" class="title title-info"><?=$data['judul']?></a></h3>
							<ul>
								<li><p class="author author-info"><a href="#" class="author"><?=$data['nama']?></a></p></li>
								<li class="right-list"><p class="views views-info">Di Unggah <?=$data['tanggal']?></p></li>
							</ul>
						</div>
					</div>
                    
         <?php
  }
  ?>
                    
                   
        </div>     </div>     </div>         
                    
                
                
                
                
                
                
                   <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
			<div class="main-grids">
				<div class="top-grids">
					<div class="recommended-info">
						<h3>Kesehatan</h3>
					
                    </div>
                   
                   <?php 

		$tampil = mysql_query("select * from video_upload WHERE Kategori = 'Kesehatan' LIMIT 3 ");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
					<div class="col-md-4 resent-grid recommended-grid slider-top-grids">
						<div class="resent-grid-img recommended-grid-img">
				<a href="videolengkap.php?id=<?php echo $data['id_video']; ?>"><video id="my-video" class="video-js" controls preload="auto" width="355" height="260"
  poster="images/<?=$data['tumb']?>" data-setup="{}">
    <source src="uploads/<?=$data['file']?>" type='video/mp4'>
    <source src="MY_VIDEO.webm" type='video/webm'>
  </video></a>
							
							
						</div>
                        

						<div class="resent-grid-info recommended-grid-info">
							<h3><a href="videolengkap.php?id=<?php echo $data['id_video']; ?>" class="title title-info"><?=$data['judul']?></a></h3>
							<ul>
								<li><p class="author author-info"><a href="#" class="author"><?=$data['nama']?></a></p></li>
								<li class="right-list"><p class="views views-info">Di Unggah <?=$data['tanggal']?></p></li>
							</ul>
						</div>
					</div>
                    
         <?php
  }
  ?>
                    
                   
        </div>     </div>     </div>         
                    
                  <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
			<div class="main-grids">
				<div class="top-grids">
					<div class="recommended-info">
						<h3>Pendidikan</h3>
					
                    </div>
                   
                   <?php 

		$tampil = mysql_query("select * from video_upload WHERE Kategori = 'Pendidikan' LIMIT 3 ");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
					<div class="col-md-4 resent-grid recommended-grid slider-top-grids">
						<div class="resent-grid-img recommended-grid-img">
				<a href="videolengkap.php?id=<?php echo $data['id_video']; ?>"><video id="my-video" class="video-js" controls preload="auto" width="355" height="260"
  poster="images/<?=$data['tumb']?>" data-setup="{}">
    <source src="uploads/<?=$data['file']?>" type='video/mp4'>
    <source src="MY_VIDEO.webm" type='video/webm'>
  </video></a>
							
							
						</div>
                        

						<div class="resent-grid-info recommended-grid-info">
							<h3><a href="videolengkap.php?id=<?php echo $data['id_video']; ?>" class="title title-info"><?=$data['judul']?></a></h3>
							<ul>
								<li><p class="author author-info"><a href="#" class="author"><?=$data['nama']?></a></p></li>
								<li class="right-list"><p class="views views-info">Di Unggah <?=$data['tanggal']?></p></li>
							</ul>
						</div>
					</div>
                    
         <?php
  }
  ?>
        </div>     </div>     </div>   
        
        
        
                            
                  <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
			<div class="main-grids">
				<div class="top-grids">
					<div class="recommended-info">
						<h3>Religi</h3>
					
                    </div>
                   
                   <?php 

		$tampil = mysql_query("select * from video_upload WHERE Kategori = 'Religi' LIMIT 3 ");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
					<div class="col-md-4 resent-grid recommended-grid slider-top-grids">
						<div class="resent-grid-img recommended-grid-img">
				<a href="videolengkap.php?id=<?php echo $data['id_video']; ?>"><video id="my-video" class="video-js" controls preload="auto" width="355" height="260"
  poster="images/<?=$data['tumb']?>" data-setup="{}">
    <source src="uploads/<?=$data['file']?>" type='video/mp4'>
    <source src="MY_VIDEO.webm" type='video/webm'>
  </video></a>
							
							
						</div>
                        

						<div class="resent-grid-info recommended-grid-info">
							<h3><a href="videolengkap.php?id=<?php echo $data['id_video']; ?>" class="title title-info"><?=$data['judul']?></a></h3>
							<ul>
								<li><p class="author author-info"><a href="#" class="author"><?=$data['nama']?></a></p></li>
								<li class="right-list"><p class="views views-info">Di Unggah <?=$data['tanggal']?></p></li>
							</ul>
						</div>
					</div>
                    
         <?php
  }
  ?>
        </div>     </div>     </div>   
        
        
                            
                  <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
			<div class="main-grids">
				<div class="top-grids">
					<div class="recommended-info">
						<h3>Motivasi</h3>
					
                    </div>
                   
                   <?php 

		$tampil = mysql_query("select * from video_upload WHERE Kategori = 'Motivasi' LIMIT 3 ");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
					<div class="col-md-4 resent-grid recommended-grid slider-top-grids">
						<div class="resent-grid-img recommended-grid-img">
				<a href="videolengkap.php?id=<?php echo $data['id_video']; ?>"><video id="my-video" class="video-js" controls preload="auto" width="355" height="260"
  poster="images/<?=$data['tumb']?>" data-setup="{}">
    <source src="uploads/<?=$data['file']?>" type='video/mp4'>
    <source src="MY_VIDEO.webm" type='video/webm'>
  </video></a>
							
							
						</div>
                        

						<div class="resent-grid-info recommended-grid-info">
							<h3><a href="videolengkap.php?id=<?php echo $data['id_video']; ?>" class="title title-info"><?=$data['judul']?></a></h3>
							<ul>
								<li><p class="author author-info"><a href="#" class="author"><?=$data['nama']?></a></p></li>
								<li class="right-list"><p class="views views-info">Di Unggah <?=$data['tanggal']?></p></li>
							</ul>
						</div>
					</div>
                    
         <?php
  }
  ?>
        </div>     </div>     </div>  
        