
            
            <?php
			include 'head.php';
			?>
           <div class="warper container-fluid">
        	
            <div class="page-header"><h1>Daftar Video Terupload <small>Edutube</small></h1></div>
            
            
            
                <div class="panel panel-default">
                    <div class="panel-heading">Daftar Video</div>
                    <div class="panel-body">
                    
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
                            <thead>
                                <tr>
                                    <th>Judul</th>
                                    <th>Pengupload</th>
                                    <th>Isi</th>
                                    <th>tanggal</th>
                                    <th>Total Tayang</th>
                                       <th>Aksi</th>
                                </tr>
                            </thead>
                             <?php 
include'../koneksi.php';
		$tampil = mysql_query("select * from video_upload ORDER BY id_video DESC");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
                            <tbody>
                                <tr class="odd gradeX">
                                    <td><?php echo $data['judul']; ?></td>
                                    <td><?php echo $data['nama']; ?></td>
                                    <td><?php echo $data['isi']; ?></td>
                                    <td class="center"><?php echo $data['tanggal']; ?></td>
                                    <td class="center"><?php echo $data['dilihat']; ?> Tayang</td>
                                      <td class="center">Hapus</td>
                                </tr>
                                
                            </tbody>
                            <?php
							}
							?>
                        </table>

                    </div>
                </div>
                
                
              
                
                
             
                </div>
            <?php
			include 'kaki.php'
			?>