<?php
include('session.php');
?>
<?php
include('ataslogin.php');
?>
<style type="text/css">
<!--
.style3 {font-size: 36px}
.style8 {font-size: 12px}
.style9 {font-size: 16px}
-->
</style>
<?php
$query = "select * from member where id_member = '$login_member'";
$result = mysql_query($query);
$data = mysql_fetch_array($result);
?>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
 <table width="100%" border="0">
  <tr>
    <th colspan="7" scope="col"><div align="center"><span class="style3">PROFIL SAYA</span></div></th>
    </tr>
  <tr>
    <td width="10%">&nbsp;</td>
    <td width="8%">&nbsp;</td>
    <td width="13%">&nbsp;</td>
    <td><div align="center" class="style9">EDUTUBE</div></td>
    <td width="13%">&nbsp;</td>
    <td width="5%">&nbsp;</td>
    <td width="12%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="5" rowspan="8">
       <form action="video_aksi.php" method="post" enctype="multipart/form-data"><br/><br/>
       <div align="center" class="style8 style8"><img src="foto/<?php echo $data['foto']; ?>" width="126" height="116"><br/>Hai... <?php echo $data['nama']; ?><br/>
         <br/>
        </div>
       <table width="90%" border="0">
        <tr>
          <th width="16%" height="43" class="style8 style8" scope="col"><div align="left"><strong>Nama</strong></div></th>
          <th width="3%" class="style8 style8" scope="col"><div align="center"><strong>:</strong></div></th>
          <th width="56%" class="style8 style8" scope="col"><?php echo $data['nama']; ?><label>
            <div align="left">
             
              <input type="hidden" name="id_video" id="id_video" value="<?php echo $data['id_member']; ?>"> 
              </div>
          </label></th>
          <th width="13%" class="style8 style8" scope="col">&nbsp;</th>
          <th width="6%" class="style8 style8" scope="col">&nbsp;</th>
        </tr>
        <tr>
          <td class="style8 style8"><div align="left"><strong>Alamat</strong></div></td>
          <td class="style8 style8"><div align="center"><strong>:</strong></div></td>
          <td class="style8 style8">        <?php echo $data['alamat']; ?>     </td>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
          <td width="1%" class="style8 style8">&nbsp;</td>
          <td width="1%" class="style8 style8">&nbsp;</td>
          <td width="1%" class="style8 style8">&nbsp;</td>
          <td width="1%" class="style8 style8">&nbsp;</td>
          <td width="1%" class="style8 style8">&nbsp;</td>
          <td width="1%" class="style8 style8">&nbsp;</td>
        </tr>
      
        <tr>
          <td class="style8 style8"><div align="left"><strong>Tentang</strong></div></td>
          <td class="style8 style8"><div align="center"><strong>:</strong></div></td>
          <td class="style8 style8"><label>
              <div align="left">
               <?php echo $data['tentang']; ?>              </div>
            </label></td>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
        </tr>
        <tr>
          <td class="style8 style8"><div align="left"><strong>No HP</strong></div></td>
          <td class="style8 style8"><div align="center"><strong>:</strong></div></td>
          <td class="style8 style8"><label>
              <div align="left">
                <?php echo $data['no_hp']; ?>              </div>
            </label></td>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
        </tr>
        <tr>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
        </tr>
        <tr>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8"><div align="center"></div></td>
          <td class="style8 style8"><p><br/>
              </p>
            <div align="center">              </div>
          </label></td>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
        </tr>
        <tr>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
          <td class="style8 style8">&nbsp;</td>
        </tr>
      </table>   
    </form>  </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</div>