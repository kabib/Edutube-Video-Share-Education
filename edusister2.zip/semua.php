<?php
include('session.php');
?>
<?php
include('ataslogin.php');
?>
<style type="text/css">
<!--
.style1 {font-size: 24px}
-->
</style>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
  <table width="100%" border="0">
    <tr>
      <th height="89" colspan="10" scope="col"><div align="center"><span class="style1">Semua Video</span></div></th>
    </tr>
    <tr>
      <td width="10%">&nbsp;</td>
      <td colspan="8" rowspan="5"><div align="center"> <?php 

		$tampil = mysql_query("select * from video_upload ");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
					<table width="90%" border="0">
                      <tr>
                        <th width="21%" rowspan="6" scope="col">	<a href="videolengkap.php?id=<?php echo $data['id_video']; ?>"><video id="my-video" class="video-js" controls preload="auto" width="250" height="150"
  poster="images/<?=$data['tumb']?>" data-setup="{}">
    <source src="uploads/<?=$data['file']?>" type='video/mp4'>
    <source src="MY_VIDEO.webm" type='video/webm'>
  </video></a></th>
                        <th width="2%" height="21" scope="col">&nbsp;</th>
                        <th colspan="6" rowspan="6" scope="col"><div align="left"><h3><a href="videolengkap.php?id=<?php echo $data['id_video']; ?>"><?=$data['judul']?></a></h3>                          
                          <p align="left" class="author author-info">Oleh <?=$data['nama']?>
                        </p>                          <p align="left" class="views"><?=$data['dilihat']?> tayang</p>                        <h5 align="left"><?php
$kalimat = $data['isi'];
$potongkalimat = substr($kalimat, 0, 150);
echo $potongkalimat ;
?>
                        </h5></div></th>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                      
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td width="18%">&nbsp;</td>
                        <td width="12%">&nbsp;</td>
                        <td width="12%">&nbsp;</td>
                        <td width="12%">&nbsp;</td>
                        <td width="12%">&nbsp;</td>
                        <td width="11%">&nbsp;</td>
                      </tr>
                    </table>      <hr width="100%">   <?php
  }
  ?>
					<br/> 
                    
                  </div></div>        </td>
      <td width="10%">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</div>
