<?php
include('session.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Edutube Indonesia</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="My Play Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' media="all" />
<!-- //bootstrap -->
<link href="css/dashboard.css" rel="stylesheet">
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' media="all" />
<script src="js/jquery-1.11.1.min.js"></script>
  <link href="jsvid/anggularJS.css" rel="stylesheet">

  <script src="jsvid/videojs-ie8.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' media="all" />
<script src="js/jquery-1.11.1.min.js"></script>
    <script src="jsvid/video.js"></script>
<!--start-smoth-scrolling-->
<!-- fonts -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Poiret+One' rel='stylesheet' type='text/css'>
<!-- //fonts -->
</head>
  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="profil.php"><h1><img src="images/logo.png" alt="" /></h1></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
			<div class="top-search">
				<form class="navbar-form navbar-right" action="carilogin.php" method="post">
					<input type="text" class="form-control" placeholder="Cari Video..." name="search">
					<input type="submit" value=" ">
				</form>
			</div>
			<div class="header-top-right">
				<div class="file">
					<a href="upload2.php">Upload</a>
				</div>
                <div class="file">
					<a href="logout.php">Logout</a>
				</div>	
					
				
		<div class="clearfix"> </div>
      </div>
    </nav>
	
       <div class="col-sm-3 col-md-2 sidebar">
			<div class="top-navigation">
				<div class="t-menu">MENU</div>
				<div class="t-img">
					<img src="images/lines.png" alt="" />
				</div>
				<div class="clearfix"> </div>
			</div>
				<div class="drop-navigation drop-navigation">
				  <ul class="nav nav-sidebar">
                  <li class="active"><a href="studio.php" class="home-icon"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Studio Saya</a></li>
					<li><a href="lihat_profil.php" class="home-icon"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Detail Profil</a></li>
					<li><a href="kesehatanlogin.php" class="user-icon"><span class="glyphicon glyphicon-home glyphicon-blackboard" aria-hidden="true"></span>Kesehatan</a></li>
					<li><a href="religilogin.php" class="sub-icon"><span class="glyphicon glyphicon-home glyphicon-hourglass" aria-hidden="true"></span>Religi</a></li>
					
					
					<li><a href="pendidikanlogin.php" class="song-icon"><span class="glyphicon glyphicon-music" aria-hidden="true"></span>Pendidikan</a></li>
					<li><a href="motivasilogin.php" class="news-icon"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Motivasi</a></li>
                    <li><a href="trendinglogin.php" class="news-icon"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Tren Video</a></li>
                    
                    <li><a href="semua.php" class="news-icon"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Semua Video</a></li>
				  </ul>
				  <!-- script-for-menu -->
						<script>
							$( ".top-navigation" ).click(function() {
							$( ".drop-navigation" ).slideToggle( 300, function() {
							// Animation complete.
							});
							});
						</script>
					<div class="side-bottom">
						<div class="side-bottom-icons">
							<ul class="nav2">
								<li><a href="#" class="facebook"> </a></li>
								<li><a href="#" class="facebook twitter"> </a></li>
								<li><a href="#" class="facebook chrome"> </a></li>
								<li><a href="#" class="facebook dribbble"> </a></li>
							</ul>
						</div>
						<div class="copyright">
							<p>Copyright © 2016 Edutube. All Rights Reserved | Design by <a href="http://w3layouts.com/">Edutube Indonesia</a></p>
						</div>
					</div>
				</div>
        </div>