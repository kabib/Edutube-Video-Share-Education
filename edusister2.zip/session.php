<?php
// Membangun Koneksi dengan Server dengan nama server, user_id dan password sebagai parameter
$connection = mysql_connect("localhost", "root", "");
// Seleksi Database
$db = mysql_select_db("edutube2", $connection);
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

// Menyimpan Session
$user_check=$_SESSION['login_user'];
// Ambil nama karyawan berdasarkan username karyawan dengan mysql_fetch_assoc
$ses_sql=mysql_query("select username, id_member, foto from member where username='$user_check'", $connection);
$row = mysql_fetch_assoc($ses_sql);
$login_session =$row['username'];
$login_member =$row['id_member'];
$login_foto =$row['foto'];
if(!isset($login_session)){
mysql_close($connection); // Menutup koneksi
header('Location: profil.php'); // Mengarahkan ke Home Page
}
?>