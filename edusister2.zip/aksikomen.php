

<?php
include("koneksi.php");
$tanggal	= date('d M Y H:i');
$id_vid = "$_POST[id_video]";
$query = "insert into komentar (isi_komentar, nama_user, id_user, id_video, foto, tanggal) values ('$_POST[komentar]', '$_POST[nama_user]', '$_POST[id_member]', '$_POST[id_video]', '$_POST[foto]', '$tanggal')";


$result = mysql_query($query);

if ($result) {
	header("location: videolog.php?id=$id_vid");
}
else {
	echo "proses simpan gagal !.";
}
?>