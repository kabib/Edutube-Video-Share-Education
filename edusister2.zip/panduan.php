<?php
include('session.php');
?>
<?php
include('ataslogin.php');
?>
<style type="text/css">
<!--
.style3 {font-size: 36px}
.style4 {font-size: 16px}
-->
</style>

<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
 <table width="100%" border="0">
  <tr>
    <th colspan="7" scope="col"><div align="center"><span class="style3">PANDUAN PENGUNAAN</span></div></th>
    </tr>
  <tr>
    <td width="2%">&nbsp;</td>
    <td width="8%"><span class="style4"></span></td>
    <td width="13%"><span class="style4"></span></td>
    <td width="58%"><div align="center" class="style4">EDUTUBE</div></td>
    <td width="13%">&nbsp;</td>
    <td width="1%">&nbsp;</td>
    <td width="5%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="5" rowspan="8"><p class="style4">&nbsp;</p>
      <p class="style4">1. Masuk Mengunakan Akun Yang telah terdaftar</p>
      <p class="style4"><img src="panduan/v1.png" width="634" height="276"> </p>
      <p class="style4">2. Pilih Button Upload pada menu dan akan tampil seperti gambar di bawah ini</p>
      <p class="style4"><img src="panduan/v2.png" width="542" height="278"></p>
      <p class="style4">3. isi semua field dan jangan lupa klik upload untuk mengupload video sampai proses selesai</p></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</div>