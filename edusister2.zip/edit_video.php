<?php
include('session.php');
?>
<?php
include('ataslogin.php');
?>
<style type="text/css">
<!--
.style3 {font-size: 36px}
-->
</style>
<?php
$query = "select * from video_upload where id_video = '$_GET[id]'";
$result = mysql_query($query);
$data = mysql_fetch_array($result);
?>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
 <table width="100%" border="0">
  <tr>
    <th colspan="7" scope="col"><div align="center"><span class="style3">STUDIO SAYA</span></div></th>
    </tr>
  <tr>
    <td width="10%">&nbsp;</td>
    <td width="8%">&nbsp;</td>
    <td width="13%">&nbsp;</td>
    <td><div align="center">EDIT VIDEO STUDIO</div></td>
    <td width="13%">&nbsp;</td>
    <td width="5%">&nbsp;</td>
    <td width="12%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="5" rowspan="8">
       <form action="video_aksi.php" method="post" enctype="multipart/form-data"><br/><br/>
      <table width="90%" border="0">
        <tr>
          <th width="19%" height="43" scope="col"><div align="left"><strong>Judul</strong></div></th>
          <th width="4%" scope="col"><strong>:</strong></th>
          <th width="58%" scope="col"><label>
            <div align="left">
              <input type="text" name="judul" id="judul" value="<?php echo $data['judul']; ?>">
              <input type="hidden" name="id_video" id="id_video" value="<?php echo $data['id_video']; ?>"> 
          
              </div>
          </label></th>
          <th width="13%" scope="col">&nbsp;</th>
          <th width="6%" scope="col">&nbsp;</th>
        </tr>
        <tr>
          <td><div align="left"><strong>Diskripsi</strong></div></td>
          <td><strong>:</strong></td>
          <td><label>
            <div align="left">
              <textarea name="isi" id="diskripsi"><?php echo $data['isi']; ?></textarea>
              </div>
          </label></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="130"><div align="left"><strong>Tambah Tumbermile</strong></div></td>
          <td><strong>:</strong></td>
          <td><img src="images/<?php echo $data['tumb']; ?>" width="317" height="189"></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>	<input type=file name=gambar><br/>*kosongkan jika gambar tidak di ubah </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><label>
            <div align="center">
              <input type="submit" name="button" id="button" value="Simpan">
              </div>
          </label></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>   
    </form>  </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</div>